#!/usr/bin/env python3
"""SSH helper for the SarResid demo server (195.248.241.14)."""
import sys
import paramiko

HOST = '195.248.241.14'
USER = 'root'
PASSWORD = '@@ZAI6677'


def get_client():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=25)
    return client


def run(cmd, timeout=600):
    client = get_client()
    try:
        stdin, stdout, stderr = client.exec_command(cmd, timeout=timeout)
        out = stdout.read().decode()
        err = stderr.read().decode()
        code = stdout.channel.recv_exit_status()
        return code, out, err
    finally:
        client.close()


def put(local, remote):
    client = get_client()
    try:
        sftp = client.open_sftp()
        sftp.put(local, remote)
        sftp.close()
        return True
    finally:
        client.close()


if __name__ == '__main__':
    if sys.argv[1] == 'run':
        code, out, err = run(sys.argv[2])
        print(out)
        if err.strip():
            print('[stderr]', err)
        sys.exit(code)
    elif sys.argv[1] == 'put':
        ok = put(sys.argv[2], sys.argv[3])
        print('uploaded' if ok else 'failed')
