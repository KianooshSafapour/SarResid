/**
 * SMS sending library — kavenegar driver (Agent API-2).
 *
 * Settings live in the Setting KV table:
 *   sms:enabled ('true'|'false'), sms:provider (kavenegar|ippanel|payamak-panel|custom),
 *   sms:apiKey, sms:sender, sms:recipients (comma-separated mobiles), sms:lowstockTemplate.
 * Values are stored as raw strings (seed format) but older rows may be JSON-encoded —
 * parseSetting handles both.
 */
import { db } from '@/lib/db'
import { toEnDigits } from '@/lib/jalali'

export const SMS_PROVIDER_WHITELIST = ['kavenegar', 'ippanel', 'payamak-panel', 'custom']

/** Default low-stock alert text ({name} / {stock} placeholders) */
export const DEFAULT_LOWSTOCK_TEMPLATE =
  'هایپر زیتون: کالای «{name}» به حد سفارش مجدد رسید (موجودی: {stock}). لطفاً سفارش ثبت شود.'

export interface SmsConfig {
  enabled: boolean
  provider: string
  apiKey: string
  sender: string
  recipients: string[] // normalized 09xxxxxxxxx list
  lowstockTemplate: string
}

/** Setting values may be JSON-encoded («"x"», «6», «false») or raw text — normalize to string. */
export function parseSetting(raw: string | null | undefined, fallback = ''): string {
  if (raw === null || raw === undefined) return fallback
  const s = String(raw).trim()
  if (!s) return fallback
  try {
    const parsed = JSON.parse(s)
    if (typeof parsed === 'string') return parsed
    if (typeof parsed === 'boolean' || typeof parsed === 'number') return String(parsed)
    return s
  } catch {
    return s // raw Persian text (seed format) — not valid JSON
  }
}

export function parseBoolSetting(raw: string | null | undefined): boolean {
  const v = parseSetting(raw, 'false').toLowerCase()
  return v === 'true' || v === '1' || v === 'yes'
}

/** Read the full SMS config from the Setting table. */
export async function getSmsConfig(): Promise<SmsConfig> {
  const rows = await db.setting.findMany({
    where: { key: { in: ['sms:enabled', 'sms:provider', 'sms:apiKey', 'sms:sender', 'sms:recipients', 'sms:lowstockTemplate'] } },
  })
  const map = new Map(rows.map((r) => [r.key, r.value]))
  const recipientsRaw = parseSetting(map.get('sms:recipients'), '')
  return {
    enabled: parseBoolSetting(map.get('sms:enabled')),
    provider: parseSetting(map.get('sms:provider'), ''),
    apiKey: parseSetting(map.get('sms:apiKey'), ''),
    sender: parseSetting(map.get('sms:sender'), ''),
    recipients: recipientsRaw
      .split(/[,،؛\n;]+/)
      .map((s) => s.trim())
      .filter(Boolean),
    lowstockTemplate: parseSetting(map.get('sms:lowstockTemplate'), DEFAULT_LOWSTOCK_TEMPLATE) || DEFAULT_LOWSTOCK_TEMPLATE,
  }
}

/** Upsert one sms: setting key (raw string storage, matches the seed format). */
export async function setSmsSetting(key: string, value: string): Promise<void> {
  await db.setting.upsert({ where: { key }, create: { key, value }, update: { value } })
}

/**
 * Normalize an Iranian mobile number to 09xxxxxxxxx.
 * Accepts 09…, +98…, 0098…, 98…, 9… (10 digits) and Persian/Arabic digits.
 * Returns null when the number is invalid.
 */
export function normalizeMobile(input: string | null | undefined): string | null {
  let s = toEnDigits(String(input ?? '')).replace(/[\s\-()._]/g, '')
  if (s.startsWith('+98')) s = '0' + s.slice(3)
  else if (s.startsWith('0098')) s = '0' + s.slice(4)
  else if (s.length === 12 && s.startsWith('98')) s = '0' + s.slice(2)
  else if (s.length === 10 && s.startsWith('9')) s = '0' + s
  return /^09\d{9}$/.test(s) ? s : null
}

/** Mask an API key for display: «••••••1234» (last 4 chars visible). */
export function maskKey(key: string): string {
  if (!key) return ''
  if (key.length <= 4) return '••••••'
  return `••••••${key.slice(-4)}`
}

export interface SmsResult {
  ok: boolean
  error?: string
  messageId?: string | null
  provider?: string
}

/**
 * Send an SMS through the configured panel.
 * - !enabled or missing provider/apiKey → {ok:false, error:'پنل پیامک تنظیم نشده'}
 *   (caller should mark the SmsOutbox row SKIPPED with this error note).
 * - kavenegar: GET https://api.kavenegar.com/v1/{apiKey}/sms/send.json?receptor=&message=
 *   with an 8s timeout; success = {return:{status:200}}.
 * - Other providers are not wired yet → explicit Persian error.
 */
export async function sendSms(opts: { to: string; text: string; config?: SmsConfig }): Promise<SmsResult> {
  const cfg = opts.config ?? (await getSmsConfig())
  if (!cfg.enabled) return { ok: false, error: 'پنل پیامک تنظیم نشده' }
  if (!cfg.provider || !cfg.apiKey) return { ok: false, error: 'پنل پیامک تنظیم نشده' }

  const to = normalizeMobile(opts.to)
  if (!to) return { ok: false, error: 'شماره موبایل گیرنده نامعتبر است' }
  const text = String(opts.text ?? '').trim()
  if (!text) return { ok: false, error: 'متن پیامک خالی است' }

  if (cfg.provider !== 'kavenegar') {
    return { ok: false, error: `ارسال از پنل «${cfg.provider}» فعلاً پشتیبانی نمی‌شود` }
  }

  try {
    const url =
      `https://api.kavenegar.com/v1/${encodeURIComponent(cfg.apiKey)}/sms/send.json` +
      `?receptor=${encodeURIComponent(to)}&message=${encodeURIComponent(text)}` +
      (cfg.sender ? `&sender=${encodeURIComponent(cfg.sender)}` : '')
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) })
    if (!res.ok) return { ok: false, error: `خطای پنل پیامک (کد ${toEnDigits(String(res.status))})` }
    const data = (await res.json().catch(() => null)) as
      | { return?: { status?: number; message?: string }; entries?: Array<{ messageid?: number | string }> }
      | null
    if (data?.return?.status === 200) {
      const mid = data.entries?.[0]?.messageid
      return { ok: true, provider: 'kavenegar', messageId: mid !== undefined ? String(mid) : null }
    }
    const msg = data?.return?.message
    return { ok: false, error: msg ? `پنل پیامک: ${msg}` : 'ارسال پیامک ناموفق بود' }
  } catch {
    return { ok: false, error: 'ارتباط با پنل پیامک برقرار نشد (مهلت پاسخ پایان یافت)' }
  }
}

/** Render the low-stock template with {name} / {stock} placeholders. */
export function renderLowstockText(template: string, product: { name: string; stock: number }): string {
  const t = template || DEFAULT_LOWSTOCK_TEMPLATE
  return t.replace(/\{name\}/g, product.name).replace(/\{stock\}/g, toEnDigits(String(product.stock)))
}
