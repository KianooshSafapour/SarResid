import { ok, fail, logActivity } from '@/lib/api'
import { getSessionUser } from '@/lib/auth'
import { getHolooConfig, holooLogin, getHolooSettings } from '@/lib/holoo'

export const dynamic = 'force-dynamic'

/**
 * GET /api/holoo/test — آزمایش اتصال به هدف فعال (شبیه‌ساز یا هلو واقعی):
 * لاگین + GET /Settings → {ok, latencyMs, currency} (OWNER/GM/ADMIN)
 */
export async function GET() {
  const user = await getSessionUser()
  if (!user) return fail('ابتدا وارد شوید', 401)
  if (!['OWNER', 'GM', 'ADMIN'].includes(user.role)) {
    return fail('آزمایش اتصال هلو فقط برای مدیران ارشد مجاز است', 403)
  }

  const cfg = await getHolooConfig()
  if (!cfg.enabled) {
    return fail('اتصال هلو غیرفعال است — ابتدا از تنظیمات فعال کنید')
  }

  const t0 = Date.now()
  try {
    await holooLogin(cfg)
    const settings = await getHolooSettings(cfg)
    const latencyMs = Date.now() - t0
    const currency = settings?.CurrencyUnit?.[0]?.string || ''
    await logActivity({
      userId: user.id,
      userName: user.fullName,
      action: 'holoo.test',
      actionLabel: 'آزمایش اتصال هلو',
      category: 'settings',
      detail: `موفق — هدف: ${cfg.useMock ? 'شبیه‌ساز' : 'هلو واقعی'} — تأخیر ${latencyMs} میلی‌ثانیه`,
    })
    return ok({
      ok: true,
      latencyMs,
      currency,
      target: cfg.useMock ? 'mock' : 'real',
      username: cfg.username,
      dbname: cfg.dbname,
    })
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'آزمایش اتصال هلو ناموفق بود'
    return fail(msg, 502)
  }
}
