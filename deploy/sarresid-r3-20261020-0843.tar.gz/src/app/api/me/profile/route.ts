import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, logActivity } from '@/lib/api'
import { getSessionUser } from '@/lib/auth'
import { toEnDigits } from '@/lib/jalali'

export const dynamic = 'force-dynamic'

/**
 * PATCH /api/me/profile { fullName?, honorific?, phone?, title?, avatarJson? }
 * — ویرایش نمایهٔ شخصی (حساب من)
 */
export async function PATCH(req: NextRequest) {
  const me = await getSessionUser()
  if (!me) return fail('نیاز به ورود', 401)

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null
  if (!body || typeof body !== 'object') return fail('درخواست نامعتبر است')

  const data: Record<string, unknown> = {}
  const changes: string[] = []

  if (body.fullName !== undefined) {
    const fullName = String(body.fullName ?? '').trim()
    if (fullName.length < 2) return fail('نام کامل را وارد کنید')
    if (fullName !== me.fullName) {
      data.fullName = fullName
      changes.push('نام')
    }
  }
  if (body.honorific !== undefined && String(body.honorific ?? '') !== me.honorific) {
    data.honorific = String(body.honorific ?? '')
    changes.push('عنوان احترامی')
  }
  if (body.title !== undefined && String(body.title ?? '') !== me.title) {
    data.title = String(body.title ?? '')
    changes.push('عنوان شغلی')
  }
  if (body.phone !== undefined) {
    const phone = typeof body.phone === 'string' && toEnDigits(body.phone).replace(/\D/g, '') || null
    const clean = phone || null
    if (clean !== me.phone) {
      data.phone = clean
      changes.push('شماره تماس')
    }
  }
  if (body.avatarJson !== undefined) {
    const avatarJson = String(body.avatarJson ?? '').trim()
    if (avatarJson && avatarJson !== me.avatarJson) {
      try {
        JSON.parse(avatarJson)
      } catch {
        return fail('قالب تصویر نمایه معتبر نیست')
      }
    }
    data.avatarJson = avatarJson || null
    changes.push('تصویر نمایه')
  }

  if (changes.length === 0) return fail('تغییری برای ذخیره وجود ندارد')

  const updated = await db.user.update({ where: { id: me.id }, data })

  await logActivity({
    userId: me.id,
    userName: me.fullName,
    action: 'me.profile',
    actionLabel: 'ویرایش نمایه',
    category: 'auth',
    detail: changes.join('، '),
  })

  return ok({
    user: {
      id: updated.id,
      fullName: updated.fullName,
      honorific: updated.honorific,
      title: updated.title,
      phone: updated.phone,
      avatarJson: updated.avatarJson,
    },
    updated: changes,
  })
}
