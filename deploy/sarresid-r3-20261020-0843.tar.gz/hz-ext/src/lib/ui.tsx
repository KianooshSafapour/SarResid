/**
 * HZ-EXT UI kit — shared components for round-3 views.
 * Available via '../lib/hz': JalaliDate, Stepper, TourEngine, printHTML,
 * barcode128, amountWords, numberToPersianWords, minutesToHM.
 * Everything is RTL-first, Persian digits, emerald/teal/amber/rose/stone palette.
 */
import React, {
  useState, useEffect, useMemo, useRef, useCallback,
} from 'hz:react'
import { jsx, jsxs } from 'hz:jsx'
import { useShell } from 'hz:shell'
import { cn } from 'hz:cn'
import { Button } from 'hz:button'
import { Input } from 'hz:input'
import {
  JALALI_MONTHS, WEEKDAY_FA, jalaliMonthLength, parseJalali, toEnDigits,
  toFaDigits, todayJalali, formatJalaliLong,
} from 'hz:jalali'
import { I } from './icons'

export { React }

/* ═══════════════════════ ۱) تاریخ‌گیر جلالی ═══════════════════════ */

function pad2(n: number) { return String(n).padStart(2, '0') }

export interface JalaliDateProps {
  value: string            // '1405-07-27' or ''
  onChange: (v: string) => void
  placeholder?: string
  className?: string
  disabled?: boolean
  quickChips?: { label: string; deltaDays: number }[] // e.g. [{label:'فردا', deltaDays:1}]
  /** اگر true باشد ورودی از صفحه‌کلید هم پذیرفته می‌شود (پیش‌فرض) */
  editable?: boolean
}

/** انتخابگر تاریخ شمسی با تقویم بازشو — جایگزین ورودی متنی تاریخ */
export function JalaliDate(props: JalaliDateProps) {
  const { value, onChange, placeholder = '۱۴۰۵-۰۷-۲۷', className, disabled, quickChips, editable = true } = props
  const [open, setOpen] = useState(false)
  const [view, setView] = useState<{ jy: number; jm: number }>(() => {
    const p = parseJalali(value || '')
    const t = todayJalali().split('-').map(Number)
    return p && p.jy ? { jy: p.jy, jm: p.jm } : { jy: t[0], jm: t[1] }
  })
  const boxRef = useRef<HTMLDivElement | null>(null)
  const inputRef = useRef<HTMLInputElement | null>(null)

  useEffect(() => {
    if (!open) return
    const onDoc = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', onDoc)
    return () => document.removeEventListener('mousedown', onDoc)
  }, [open])

  useEffect(() => {
    if (!open) return
    const p = parseJalali(value || '')
    if (p && p.jy) setView({ jy: p.jy, jm: p.jm })
  }, [open]) // eslint-disable-line react-hooks/exhaustive-deps

  const today = todayJalali()
  const [ty, tm, td] = today.split('-').map(Number)
  const sel = parseJalali(value || '')
  const monthLen = jalaliMonthLength(view.jy, view.jm)
  const firstWeekday = useMemo(() => {
    const d = parseJalali(`${view.jy}-${pad2(view.jm)}-01`)
    return d ? d.getDay() : 0 // getDay: Sat=6 … Fri=5 (js) → convert to fa col
  }, [view])
  // Persian week: شنبه(0) یک‌شنبه(1) … جمعه(6). js getDay: Sun=0…Sat=6
  const firstCol = ((firstWeekday + 1) % 7)

  const cells: (number | null)[] = []
  for (let i = 0; i < firstCol; i++) cells.push(null)
  for (let d = 1; d <= monthLen; d++) cells.push(d)

  function pick(d: number) {
    onChange(`${view.jy}-${pad2(view.jm)}-${pad2(d)}`)
    setOpen(false)
  }
  function shiftMonth(delta: number) {
    let { jy, jm } = view
    jm += delta
    if (jm < 1) { jm = 12; jy-- } else if (jm > 12) { jm = 1; jy++ }
    setView({ jy, jm })
  }

  return (
    <div className="relative" ref={boxRef as any}>
      <div className="relative">
        <I.calendarDays size={15} className="pointer-events-none absolute top-1/2 right-2.5 -translate-y-1/2 text-stone-400" />
        <input
          ref={inputRef as any}
          dir="ltr"
          className={cn('hz-jalali-input num h-9 w-full rounded-md border border-input bg-background pr-8 text-center text-sm outline-none transition-colors focus:border-emerald-500 disabled:cursor-not-allowed disabled:opacity-50', className)}
          value={value ? toFaDigits(value) : ''}
          placeholder={placeholder}
          disabled={disabled}
          readOnly={!editable}
          onChange={(e: any) => onChange(toEnDigits(String(e.target.value)).replace(/[^\d-]/g, ''))}
          onFocus={() => !disabled && setOpen(true)}
          onClick={() => !disabled && setOpen(true)}
        />
      </div>
      {open && !disabled && (
        <div className="absolute z-50 mt-1.5 w-64 rounded-xl border border-stone-200 bg-white p-2.5 shadow-xl" dir="rtl">
          {/* سربرگ ماه */}
          <div className="mb-2 flex items-center justify-between">
            <button type="button" className="rounded-md p-1 text-stone-500 transition-colors hover:bg-stone-100" onClick={() => shiftMonth(1)} aria-label="ماه بعد" title="ماه بعد">
              <I.chevronLeft size={16} />
            </button>
            <div className="text-xs font-bold text-stone-700">{JALALI_MONTHS[view.jm - 1]} {toFaDigits(String(view.jy))}</div>
            <button type="button" className="rounded-md p-1 text-stone-500 transition-colors hover:bg-stone-100" onClick={() => shiftMonth(-1)} aria-label="ماه قبل" title="ماه قبل">
              <I.chevronRight size={16} />
            </button>
          </div>
          {/* روزهای هفته */}
          <div className="mb-1 grid grid-cols-7 gap-0.5">
            {WEEKDAY_FA.map((w: string, i: number) => (
              <div key={i} className={cn('py-0.5 text-center text-[9.5px] font-medium', i === 6 ? 'text-rose-500' : 'text-stone-400')}>{w}</div>
            ))}
          </div>
          {/* روزها */}
          <div className="grid grid-cols-7 gap-0.5">
            {cells.map((d, i) => {
              if (d == null) return <div key={`e${i}`} />
              const ds = `${view.jy}-${pad2(view.jm)}-${pad2(d)}`
              const isToday = ds === today
              const isSel = !!sel && sel.jy === view.jy && sel.jm === view.jm && sel.jd === d
              const isFri = i % 7 === 6
              return (
                <button
                  key={d} type="button"
                  onClick={() => pick(d)}
                  className={cn(
                    'h-7 rounded-md text-[11px] font-medium transition-colors',
                    isSel ? 'bg-emerald-600 text-white shadow-sm'
                      : isToday ? 'border border-emerald-400 text-emerald-800'
                        : isFri ? 'text-rose-500 hover:bg-rose-50' : 'text-stone-600 hover:bg-stone-100',
                  )}
                >
                  {toFaDigits(String(d))}
                </button>
              )
            })}
          </div>
          {/* پابرگ */}
          <div className="mt-2 flex items-center justify-between border-t border-stone-100 pt-2">
            <button type="button" className="rounded-md px-2 py-1 text-[11px] font-bold text-emerald-700 transition-colors hover:bg-emerald-50"
              onClick={() => { onChange(today); setOpen(false) }}>
              امروز
            </button>
            {value && (
              <button type="button" className="rounded-md px-2 py-1 text-[11px] text-stone-500 transition-colors hover:bg-stone-100"
                onClick={() => { onChange(''); setOpen(false) }}>
                پاک کردن
              </button>
            )}
            <span className="text-[10px] text-stone-400">{formatJalaliLong(parseJalali(today as any) as any)}</span>
          </div>
          {!!quickChips?.length && (
            <div className="mt-1.5 flex flex-wrap gap-1 border-t border-stone-100 pt-2">
              {quickChips.map((ch) => {
                const d = parseJalali(today)
                if (!d) return null
                d.setDate(d.getDate() + ch.deltaDays)
                const jy = Number(toFaDigits(String(d.getFullYear())) ? d.getFullYear() : 0) // fallback unused
                void jy
                // build jalali from js date
                const conv = jsDateToJalali(d)
                return (
                  <button key={ch.label} type="button"
                    className="rounded-md border border-stone-200 px-2 py-0.5 text-[10.5px] text-stone-600 transition-colors hover:border-emerald-400 hover:text-emerald-700"
                    onClick={() => { onChange(conv); setOpen(false) }}>
                    {ch.label}
                  </button>
                )
              })}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

/** تبدیل Date میلادی → رشته جلالی YYYY-MM-DD (بدون وابستگی به ماژول جانبی) */
export function jsDateToJalali(date: Date): string {
  const gy = date.getFullYear(), gm = date.getMonth() + 1, gd = date.getDate()
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
  let jy = gy <= 1600 ? 0 : 979
  const gy2 = gy <= 1600 ? gy - 621 : gy - 1600
  const gy3 = gm > 2 ? gy2 + 1 : gy2
  let days = (365 * gy2) + Math.floor((gy3 + 3) / 4) - Math.floor((gy3 + 99) / 100)
    + Math.floor((gy3 + 399) / 400) - 80 + gd + g_d_m[gm - 1]
  jy += 33 * Math.floor(days / 12053); days %= 12053
  jy += 4 * Math.floor(days / 1461); days %= 1461
  if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365 }
  const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30)
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30)
  return `${jy}-${pad2(jm)}-${pad2(jd)}`
}

/* ═══════════════════════ ۲) پله‌شمار (− مقدار +) ═══════════════════════ */

export interface StepperProps {
  value: number
  onChange: (v: number) => void
  min?: number
  max?: number
  step?: number
  size?: 'sm' | 'md'
  disabled?: boolean
  /** متن کوچک زیر مقدار (مثل «کارتن ×۱۲») */
  hint?: string
}

export function Stepper(props: StepperProps) {
  const { value, onChange, min = 0, max = 9999, step = 1, size = 'md', disabled, hint } = props
  const btn = size === 'sm'
    ? 'h-7 w-7 rounded-md text-stone-600 hover:bg-stone-100 disabled:opacity-30'
    : 'h-8 w-8 rounded-md text-stone-600 hover:bg-stone-100 disabled:opacity-30'
  return (
    <div className="inline-flex flex-col items-center gap-0.5">
      <div className="inline-flex items-center gap-0.5 rounded-lg border border-stone-200 bg-white p-0.5" dir="rtl">
        <button type="button" className={btn} disabled={disabled || value <= min}
          onClick={() => onChange(Math.max(min, value - step))} aria-label="کم کردن" title="کم کردن">
          <I.minus size={13} />
        </button>
        <span className={cn('num min-w-7 text-center font-bold text-stone-800', size === 'sm' ? 'text-xs' : 'text-sm')}>
          {toFaDigits(String(value))}
        </span>
        <button type="button" className={btn} disabled={disabled || value >= max}
          onClick={() => onChange(Math.min(max, value + step))} aria-label="زیاد کردن" title="زیاد کردن">
          <I.plus size={13} />
        </button>
      </div>
      {hint && <span className="text-[9.5px] text-stone-400">{hint}</span>}
    </div>
  )
}

/* ═══════════════════════ ۳) موتور تور تعاملی ═══════════════════════ */

export interface TourStep {
  /** سلکتور CSS هدف (مثل '[data-tour="rail"]') — نبود = تور مرکزی */
  target?: string
  /** قبل از هایلایت به این view برو (مثل 'supply/orders') */
  go?: string
  title: string
  body: string
  mobileHint?: string
}

export interface TourEngineProps {
  open: boolean
  steps: TourStep[]
  onClose: () => void      // رد کردن
  onDone: () => void       // پایان طبیعی
}

/**
 * تور تعاملی با تاریک‌سازی چهارپاره (پنل‌های بالا/پایین/چپ/راست) —
 * برخلاف تور قدیمی، در «همهٔ» مرحله‌ها صفحه تاریک می‌ماند.
 */
export function TourEngine(props: TourEngineProps) {
  const { open, steps, onClose, onDone } = props
  const { go } = useShell() as any
  const [idx, setIdx] = useState(0)
  const [rect, setRect] = useState<DOMRect | null>(null)
  const rafRef = useRef<number | null>(null)

  const step = steps[idx]

  const measure = useCallback(() => {
    rafRef.current = requestAnimationFrame(() => {
      if (!step?.target) { setRect(null); return }
      const el = document.querySelector(step.target)
      if (!el || !(el as HTMLElement).offsetParent) { setRect(null); return }
      const r = el.getBoundingClientRect()
      setRect(r.width > 0 && r.height > 0 ? r : null)
    })
  }, [step])

  useEffect(() => { if (open) { setIdx(0) } }, [open]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!open) return
    let cancelled = false
    async function enter() {
      if (step?.go) {
        try { go(step.go) } catch { /* ignore */ }
        await new Promise((res) => setTimeout(res, 450))
      }
      if (!cancelled) measure()
    }
    void enter()
    const onRe = () => measure()
    window.addEventListener('resize', onRe)
    window.addEventListener('scroll', onRe, true)
    return () => {
      cancelled = true
      window.removeEventListener('resize', onRe)
      window.removeEventListener('scroll', onRe, true)
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [open, idx, measure, step, go])

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { onClose(); return }
      if (e.key === 'ArrowLeft') { next() }       // در RTL چپ = جلو
      else if (e.key === 'ArrowRight') { prev() } // راست = عقب
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }) // eslint-disable-line react-hooks/exhaustive-deps

  if (!open || !step) return null

  function next() {
    if (idx < steps.length - 1) setIdx(idx + 1)
    else onDone()
  }
  function prev() { if (idx > 0) setIdx(idx - 1) }

  const vw = window.innerWidth, vh = window.innerHeight
  const PAD = 8
  const dim = 'bg-slate-900/62 transition-all duration-300'

  // جای کارت توضیح: زیر هدف (اگر جا بود) وگرنه بالا؛ افقی وسط‌چین با محدودیت
  let cardTop: number, cardLeft: number
  const cardW = Math.min(340, vw - 24)
  if (rect) {
    cardTop = rect.bottom + 12
    if (cardTop + 190 > vh) cardTop = Math.max(12, rect.top - 202)
    cardLeft = Math.min(Math.max(12, rect.left + rect.width / 2 - cardW / 2), vw - cardW - 12)
  } else {
    cardTop = vh / 2 - 110
    cardLeft = vw / 2 - cardW / 2
  }

  return (
    <div className="fixed inset-0 z-[200]" dir="rtl" role="dialog" aria-modal="true" aria-label="تور راهنمای سامانه">
      {/* تاریک‌سازی چهارپاره — همیشه فعال */}
      {rect ? (
        <>
          <div className={cn('absolute', dim)} style={{ top: 0, left: 0, right: 0, height: Math.max(0, rect.top - PAD) }} />
          <div className={cn('absolute', dim)} style={{ top: rect.bottom + PAD, left: 0, right: 0, bottom: 0 }} />
          <div className={cn('absolute', dim)} style={{ top: Math.max(0, rect.top - PAD), left: 0, width: Math.max(0, rect.left - PAD), height: rect.height + PAD * 2 }} />
          <div className={cn('absolute', dim)} style={{ top: Math.max(0, rect.top - PAD), left: rect.right + PAD, right: 0, height: rect.height + PAD * 2 }} />
          {/* حلقه هایلایت */}
          <div className="pointer-events-none absolute rounded-xl transition-all duration-300"
            style={{
              top: rect.top - PAD, left: rect.left - PAD, width: rect.width + PAD * 2, height: rect.height + PAD * 2,
              boxShadow: '0 0 0 2.5px hsl(142 76% 36% / .95), 0 0 0 6px hsl(142 76% 36% / .18)',
            }} />
        </>
      ) : (
        <div className={cn('absolute inset-0', dim)} />
      )}

      {/* کارت توضیح */}
      <div className="absolute rounded-2xl border border-stone-200 bg-white p-5 shadow-2xl"
        style={{ top: cardTop, left: cardLeft, width: cardW }}>
        <div className="mb-1 flex items-center gap-1.5">
          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-100 text-[11px] font-black text-emerald-700">
            {toFaDigits(String(idx + 1))}
          </span>
          <h3 className="text-sm font-black text-stone-800">{step.title}</h3>
        </div>
        <p className="text-[12.5px] leading-6 text-stone-600">{step.body}</p>
        {step.mobileHint && (
          <p className="mt-2 rounded-lg border border-amber-200 bg-amber-50 px-2 py-1.5 text-[11px] leading-5 text-amber-800">
            📱 {step.mobileHint}
          </p>
        )}
        <div className="mt-4 flex items-center justify-between gap-2 border-t border-stone-100 pt-3">
          {/* نقطه‌های پیشرفت */}
          <div className="flex items-center gap-1">
            {steps.map((_, i) => (
              <span key={i} className={cn('h-1.5 rounded-full transition-all', i === idx ? 'w-5 bg-emerald-600' : 'w-1.5 bg-stone-300')} />
            ))}
          </div>
          <div className="flex items-center gap-1.5">
            <button type="button" onClick={onClose}
              className="rounded-md px-2.5 py-1.5 text-[11.5px] font-medium text-stone-400 transition-colors hover:text-rose-600">
              رد کردن
            </button>
            {idx > 0 && (
              <button type="button" onClick={prev}
                className="inline-flex items-center gap-1 rounded-md border border-stone-200 px-2.5 py-1.5 text-[11.5px] font-medium text-stone-600 transition-colors hover:bg-stone-50">
                <I.chevronRight size={13} /> قبلی
              </button>
            )}
            <button type="button" onClick={next}
              className="inline-flex items-center gap-1 rounded-md bg-emerald-600 px-3 py-1.5 text-[11.5px] font-bold text-white shadow-sm transition-colors hover:bg-emerald-700">
              {idx === steps.length - 1 ? 'شروع کار' : 'بعدی'} {idx < steps.length - 1 && <I.chevronLeft size={13} />}
            </button>
          </div>
        </div>
        <div className="mt-1 text-left text-[10px] text-stone-300">{toFaDigits(String(idx + 1))} از {toFaDigits(String(steps.length))}</div>
      </div>
    </div>
  )
}

/* ═══════════════════════ ۴) چاپ حرفه‌ای (iframe) ═══════════════════════ */

/**
 * چاپ/ذخیرهٔ PDF یک سند HTML کامل در iframe مخفی.
 * @param html سند کامل (<!DOCTYPE html>…</html>) با فونت وزیرمتن از /fonts
 * @param opts.width عرض @page (پیش‌فرض A4)
 */
export function printHTML(html: string, opts?: { width?: string }) {
  const width = opts?.width || '210mm'
  const frame = document.createElement('iframe')
  frame.setAttribute('aria-hidden', 'true')
  frame.style.position = 'fixed'
  frame.style.right = '-10000px'
  frame.style.width = '0'
  frame.style.height = '0'
  frame.style.border = '0'
  document.body.appendChild(frame)
  const doc = frame.contentDocument
  if (!doc) { frame.remove(); return }
  doc.open()
  doc.write(html.replace('</head>', `<style>@page{size:${width} auto;margin:0}</style></head>`))
  doc.close()
  const doPrint = () => {
    try { frame.contentWindow?.focus(); frame.contentWindow?.print() } catch { /* ignore */ }
    setTimeout(() => frame.remove(), 4000)
  }
  // انتظار برای فونت‌ها
  setTimeout(() => {
    try {
      const f = (frame.contentWindow as any)?.document?.fonts
      if (f?.ready?.then) f.ready.then(() => setTimeout(doPrint, 120))
      else doPrint()
    } catch { doPrint() }
  }, 350)
}

/* ═══════════════════════ ۵) بارکد Code128 ═══════════════════════ */

const CODE128_PATTERNS = [
  '212222', '222122', '222221', '121223', '121322', '131222', '122213', '122312', '132212', '221213',
  '221312', '231212', '112232', '122132', '122231', '113222', '123122', '123221', '223211', '221132',
  '221231', '213212', '223112', '312131', '311222', '321122', '321221', '312212', '322112', '322211',
  '212123', '212321', '232121', '111323', '131123', '131321', '112313', '132113', '132311', '211313',
  '231113', '231311', '112133', '112331', '132131', '113123', '113321', '133121', '313121', '211331',
  '231131', '213113', '213311', '213131', '311123', '311321', '331121', '312113', '312311', '332111',
  '314111', '221411', '431111', '111224', '111422', '121124', '121421', '141122', '141221', '112214',
  '112412', '122114', '122411', '142112', '142211', '241211', '221114', '413111', '241112', '134111',
  '111242', '121142', '121241', '114212', '124112', '124211', '411212', '421112', '421211', '212141',
  '214121', '412121', '111143', '111341', '131141', '114113', '114311', '411113', '411311', '113141',
  '114131', '311141', '411131', '211412', '211214', '211232', '2331112',
]

/** رسم بارکد Code128-B روی canvas — بازگشت خودِ canvas */
export function barcode128(text: string, opts?: { height?: number; moduleWidth?: number; showText?: boolean }): HTMLCanvasElement | null {
  const height = opts?.height ?? 46
  const mw = opts?.moduleWidth ?? 1.6
  const showText = opts?.showText !== false
  const clean = String(text ?? '').replace(/[^\x20-\x7e]/g, '')
  if (!clean) return null
  const codes: number[] = [104] // Start B
  let sum = 104
  for (let i = 0; i < clean.length; i++) {
    const v = clean.charCodeAt(i) - 32
    if (v < 0 || v > 94) return null
    codes.push(v)
    sum += v * (i + 1)
  }
  codes.push(sum % 103)
  codes.push(106) // stop
  const pattern = codes.map((c) => CODE128_PATTERNS[c]).join('')
  // عرض کل ماژول‌ها
  let total = 0
  for (const ch of pattern) total += Number(ch)
  const textH = showText ? 13 : 0
  const canvas = document.createElement('canvas')
  canvas.width = Math.ceil(total * mw) + 8
  canvas.height = height + textH
  const ctx = canvas.getContext('2d')
  if (!ctx) return null
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  ctx.fillStyle = '#18181b'
  let x = 4
  let bar = true
  for (const ch of pattern) {
    const w = Number(ch) * mw
    if (bar) ctx.fillRect(x, 0, w, height)
    x += w
    bar = !bar
  }
  if (showText) {
    ctx.fillStyle = '#18181b'
    ctx.font = '600 11px Vazirmatn, Tahoma, sans-serif'
    ctx.textAlign = 'center'
    ctx.direction = 'ltr'
    ctx.fillText(clean, canvas.width / 2, height + 10)
  }
  return canvas
}

/* ═══════════════════════ ۶) حروف‌خوانی مبالغ ═══════════════════════ */

const YEKAN = ['', 'یک', 'دو', 'سه', 'چهار', 'پنج', 'شش', 'هفت', 'هشت', 'نه']
const DAHYEK = ['ده', 'یازده', 'دوازده', 'سیزده', 'چهارده', 'پانزده', 'شانزده', 'هفده', 'هجده', 'نوزده']
const DAHGAN = ['', '', 'بیست', 'سی', 'چهل', 'پنجاه', 'شصت', 'هفتاد', 'هشتاد', 'نود']
const SADGAN = ['', 'صد', 'دویست', 'سیصد', 'چهارصد', 'پانصد', 'ششصد', 'هفتصد', 'هشتصد', 'نهصد']
const SCALE = ['', 'هزار', 'میلیون', 'میلیارد', 'هزار میلیارد']

function threeDigitToWords(n: number): string {
  const parts: string[] = []
  const s = Math.floor(n / 100)
  const rest = n % 100
  if (s > 0) parts.push(SADGAN[s])
  if (rest >= 10 && rest < 20) parts.push(DAHYEK[rest - 10])
  else {
    const d = Math.floor(rest / 10)
    const y = rest % 10
    if (d > 0) parts.push(DAHGAN[d])
    if (y > 0) parts.push(YEKAN[y])
  }
  return parts.join(' و ')
}

export function numberToPersianWords(n: number): string {
  n = Math.floor(Math.abs(n))
  if (n === 0) return 'صفر'
  if (n >= 1e15) return 'عدد بسیار بزرگ'
  const groups: number[] = []
  let x = n
  while (x > 0) { groups.push(x % 1000); x = Math.floor(x / 1000) }
  const parts: string[] = []
  for (let i = groups.length - 1; i >= 0; i--) {
    const g = groups[i]
    if (g === 0) continue
    parts.push(`${threeDigitToWords(g)}${SCALE[i] ? ' ' + SCALE[i] : ''}`)
  }
  return parts.join(' و ')
}

/** حروف‌خوانی مبلغ در دو سطر: ریال و تومان */
export function amountWords(amount: number): { rial: string; toman: string } {
  const rial = `${numberToPersianWords(amount)} ریال`
  const tomans = Math.floor(amount / 10)
  const rem = amount % 10
  const toman = rem === 0
    ? `${numberToPersianWords(tomans)} تومان`
    : `${numberToPersianWords(tomans)} تومان و ${numberToPersianWords(rem)} ریال`
  return { rial, toman }
}

/* ═══════════════════════ ۷) کمک‌های زمان ═══════════════════════ */

/** ۹۵ → «۱:۳۵» */
export function minutesToHM(total: number): string {
  const t = Math.max(0, Math.round(total || 0))
  const h = Math.floor(t / 60), m = t % 60
  return toFaDigits(`${h}:${pad2(m)}`)
}
