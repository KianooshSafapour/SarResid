import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, fail, logActivity } from '@/lib/api'
import { getSessionUser } from '@/lib/auth'
import { assertPageAccess } from '@/lib/access'
import { sendViaPanelDetailed } from '@/lib/sms'

export const dynamic = 'force-dynamic'

type RouteContext = { params: Promise<{ id: string }> }

const TEST_TEXT = 'پیام آزمایشی مرکز پیامک هایپر زیتون'

/**
 * POST /api/sms/panels/[id]/test {to}
 * Sends «پیام آزمایشی مرکز پیامک هایپر زیتون» through the panel
 * (mock mode → SENT/MOCK outbox row) and updates lastTestAt / lastTestOk.
 */
export async function POST(req: NextRequest, ctx: RouteContext) {
  const user = await getSessionUser()
  if (!user) return fail('ابتدا وارد شوید', 401)
  const gate = await assertPageAccess(user, 'system/smscenter')
  if (!gate.ok) return fail(gate.deny, 403)

  const { id } = await ctx.params
  const panel = await db.smsPanel.findUnique({ where: { id } })
  if (!panel) return fail('پنل یافت نشد', 404)

  const body = await req.json().catch(() => null)
  const to = String(body?.to ?? '').trim()
  if (!to) return fail('شماره موبایل آزمایشی را وارد کنید')

  const outcome = await sendViaPanelDetailed(panel, to, TEST_TEXT, { reason: 'TEST', toName: 'آزمایش پنل' })

  await db.smsPanel.update({
    where: { id },
    data: { lastTestAt: new Date(), lastTestOk: outcome.ok },
  })

  await logActivity({
    userId: user.id,
    userName: user.fullName,
    action: 'sms.panel.test',
    actionLabel: 'مرکز پیامک',
    category: 'settings',
    detail: `آزمایش پنل «${panel.name}» → ${outcome.ok ? 'موفق' : `ناموفق${outcome.error ? ` (${outcome.error})` : ''}`}`,
    entityId: id,
  })

  return ok({
    ok: outcome.ok,
    error: outcome.ok ? null : (outcome.error ?? 'ارسال آزمایشی ناموفق بود'),
    row: {
      id: outcome.row.id,
      status: outcome.row.status,
      messageId: outcome.row.messageId,
      error: outcome.row.error,
    },
    lastTestAt: new Date().toISOString(),
    lastTestOk: outcome.ok,
  })
}
